<?php
include("connection.php");
session_start();

 

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && 
    isset($_POST['pseudo']) && isset($_POST['nom']) &&
    isset($_POST['prenom']) && isset($_POST['pwd']) &&
    isset($_POST['pwd1'])) {

    // Assign form field values to variables
    $cpt_pseudo = htmlspecialchars($_POST['pseudo']);
    $pfl_nom = htmlspecialchars($_POST['nom']);
    $pfl_prenom = htmlspecialchars($_POST['prenom']);
    $cpt_password = htmlspecialchars($_POST['pwd']);
    $mdpconf = htmlspecialchars($_POST['pwd1']);

    // Basic field validation
    if (empty($cpt_pseudo) || empty($pfl_nom) || empty($pfl_prenom) || empty($cpt_password) || empty($mdpconf)) {
        echo "<script>alert('All fields are required.');</script>";
        echo "<script>window.location.href = '../inscription/inscription.php';</script>";
        exit(); // Stop further execution if fields are empty
    }

    // Check if passwords match
    if ($cpt_password != $mdpconf) {
        echo "<script>alert('Passwords do not match.');</script>";
        echo "<script>window.location.href = '../inscription/inscription.php';</script>";
        exit();
    }

  

    // Proceed with database operations
    $sql1 = "INSERT INTO t_compte_cpt VALUES('" . addslashes($cpt_pseudo) . "',MD5('" . $cpt_password . "'));";
    $result3 = $mysqli->query($sql1);
    if ($result3 == false) {
        // The query failed
        echo "Error: Query failed \n";
        echo "Query: " . $sql1 . "\n";
        echo "Errno: " . $mysqli->errno . "\n";
        echo "Error: " . $mysqli->error . "\n";
        exit();
    } else {
        // ajout de profil
        $sql2 = "INSERT INTO t_profil_pfl VALUES('" . $cpt_pseudo . "','" . $pfl_nom . "','" . addslashes($pfl_prenom) . "','D','M');";
        $result3_1 = $mysqli->query($sql2);
        if ($result3_1 == false) {
            echo "Error: Error creating profile \n";
            echo "Query: " . $sql1 . "\n";
            echo "Errno: " . $mysqli->connect_errno . "\n";
            echo "Error: " . $mysqli->connect_error . "\n";
            $sql1 = "DELETE FROM t_compte_cpt WHERE cpt_pseudo= '" . $cpt_pseudo . "';";
            $result3_2 = $mysqli->query($sql1);
            // Stop loading the page
            exit();
        } else {
            // Set a session variable to indicate successful registration
            $_SESSION['registration_success'] = true;
            // Redirect user to the same page
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit();
        }
    }
}

// Check if registration was successful and display popup message
if (isset($_SESSION['registration_success']) && $_SESSION['registration_success']) {
    echo "<script>alert('Registration successful.');</script>";
    echo "<script>window.location.href = '../index.php';</script>";
    // Reset the session variable
    unset($_SESSION['registration_success']);
    exit(); // Add exit to prevent further execution
}

// Close the connection to the MariaDB database
$mysqli->close();
?>
