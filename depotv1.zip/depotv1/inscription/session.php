<?php

// Include the database connection file
require "connection.php";

// Start the session
session_start();

// Check if the login form has been submitted
if (isset($_POST['submit'])) {

  // Get the user-provided pseudo and password
  $cpt_pseud = $_POST['pseudo'];
  $cpt_password = $_POST['pwd'];

  // Check if the provided pseudo and password are valid
  if (!empty($cpt_pseud) && !empty($cpt_password)) {

    // Prepare the SQL query
    $stmt = $mysqli->prepare("SELECT * FROM t_compte_cpt WHERE cpt_pseudo = ? AND cpt_password = MD5(?)");

    // Bind the parameters to the query
    $stmt->bind_param("ss", $cpt_pseud, $cpt_password);

    // Execute the query
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if the query was successful
    if ($result) {

      // Check if the query returned any rows
      if ($result->num_rows == 1) {

        // Set the login session variable
        $_SESSION["login"] = $cpt_pseud;

        // Redirect to the profile page
        header("location:profil.php");

      } else {

        // Set the error session variable
        $_SESSION["erreur"] = "Email ou mot de passe invalide!";

        // Redirect to the login page
        header("location:opening_session.php");
      }

    } else {

      // Set the error session variable
      $_SESSION["erreur"] = "Erreur de connexion à la base de données.";

      // Redirect to the login page
      header("location:opening_session.php");
    }

    // Close the statement
    $stmt->close();

  } else {

    // Set the error session variable
    $_SESSION["erreur"] = "Veuillez remplir tous les champs.";

    // Redirect to the login page
    header("location:opening_session.php");
  }

} else {

  // Redirect to the login page
  header("location:opening_session.php");
}

// Close the database connection
$mysqli->close();

?>