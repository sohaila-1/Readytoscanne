<?php 
include("connection.php");
?>


<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.9.17, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.9.17, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="asset/images/logo5.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Page 5</title>

  <link rel="stylesheet" href="asset/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="asset/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="asset/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="asset/animatecss/animate.css">
  <link rel="stylesheet" href="asset/theme/css/style.css">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Inter+Tight:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter+Tight:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="asset/mobirise/css/mbr-additional.css?v=S60xhT"><link rel="stylesheet" href="asset/mobirise/css/mbr-additional.css?v=S60xhT" type="text/css">
<style>
  .styled-frame {
    border: 2px solid black;
    padding: 10px;
    margin-bottom: 20px;
}

.link {
    text-decoration: none;
    color: red;
}

.link:hover {
    color: #000;
}
  
</style>
</head>
<body>
  <section data-bs-version="5.1" class="menu menu5 cid-u76g7t6F8u" once="menu" id="menu05-21">
	

    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
      <div class="container">
        <div class="navbar-brand">
          
          <span class="navbar-caption-wrap"><a class="navbar-caption text-black display-4" href="../indix.php">NFTUniverse</a></span>
        </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <div class="hamburger">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
          </div>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
              <a class="nav-link link text-black display-4" href="indix.php">News</a>
            </li>
            <li class="nav-item">
              <a class="nav-link link text-black display-4" href="../repertoire/repertoir.php" aria-expanded="false">content</a>
            </li>
            <li class="nav-item">
              <a class="nav-link link text-black display-4" href="#">Contacts</a>
            </li></ul>
          <div class="navbar-buttons mbr-section-btn">
            <a class="btn btn-primary display-4" href="../inscription/inscription.php"> Start Now!</a>
          </div>
        </div>
      </div>
    </nav>
  </section>
  <section data-bs-version="5.1" class="image01 cid-u8pY74KyRE" id="image01-2n">
  <!-- starting section php to show the details for every card -->

  <?php
// Vérifiez si le code de la fiche est présent dans l'URL
if (isset($_GET['fic_code'])) {
    // Récupérez le code de la fiche de l'URL
    $fic_code = $_GET['fic_code'];  
    // Vérifiez si le code de la fiche a une longueur de 12 caractères
    if (strlen($fic_code) === 12) {
        // Utilisez le code de la fiche en toute sécurité
        // requete pour extraire chaque fiche avec ses données à travers son code
        $sql = "SELECT fic_code, fic_image , fic_contenu, sjt_intitule, hyp_url FROM t_fiche_fich JOIN t_sujet_sjt USING(sjt_id) JOIN t_liaison_li
         USING(fic_numero) JOIN t_hyperlien_hyp USING(hyp_id) WHERE fic_code='$fic_code' and fic_etat='P'";  
        $result = $mysqli->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();       
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-lg-6">
            <div class="image-wrapper mb-4">
              <!-- affichage de l'image de fiche et l'intitule de son sujet , aussi le contenue de fiche et ses hyperlien -->
                <img class="w-60 h-50" src="images/<?php echo $row['fic_image']; ?>" alt="">
            </div>
            <h4 class="mbr-description mbr-fonts-style mb-3 align-center display-5">
               <strong> <?php echo $row['sjt_intitule']; ?></strong>
            </h4>
            <h4 class="mbr-description mbr-fonts-style mb-0 align-center display-7">
                <?php echo $row['fic_contenu']; ?>
                <br><br>
                <h4>The links that we found for this:</h4>
<div class="styled-frame">
    <a href="<?php echo $row['hyp_url']; ?>" class="link"><?php echo $row['hyp_url']; ?></a>
</div>
                
            </p>
        </div>
    </div>
</div>

<?php    
        } else {
            echo " we are sorry those cards are not seeing for this moment ";
        }
    } else {
        echo "Invalid fic_code length";
    }
} else {
    echo "fic_code parameter is missing";
}

$mysqli->close();
?>

</section><section class="display-7" style="padding: 0;align-items: center;justify-content: center;flex-wrap: wrap;    align-content: center;display: flex;position: relative;height: 4rem;"><a href="https://mobiri.se/2318866" style="flex: 1 1;height: 4rem;position: absolute;width: 100%;z-index: 1;"><img alt="" style="height: 4rem;" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="></a>
</section><script src="asset/bootstrap/js/bootstrap.bundle.min.js"></script>  <script src="asset/smoothscroll/smooth-scroll.js"></script>  <script src="asset/ytplayer/index.js"></script> 
 <script src="asset/theme/js/script.js"></script>  

  </body>
</html>