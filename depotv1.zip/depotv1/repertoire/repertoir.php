<?php
 require "connection.php";
 ?>


<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.9.17, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.9.17, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <meta name="description" content="">
  
  
  <title>gallery</title>
  <link rel="stylesheet" href="assets2/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets2/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets2/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets2/animatecss/animate.css">
  <link rel="stylesheet" href="assets2/dropdown/css/style.css">
  <link rel="stylesheet" href="assets2/theme/css/style.css">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Inter+Tight:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter+Tight:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="assets2/mobirise/css/mbr-additional.css?v=r7HEwR"><link rel="stylesheet" href="assets2/mobirise/css/mbr-additional.css?v=r7HEwR" type="text/css">

  
  
  
</head>
<body>
  
  <section data-bs-version="5.1" class="menu menu5 cid-u7tS2UGWgO" once="menu" id="menu05-2h">
	

	<nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
		<div class="container">
			<div class="navbar-brand">
				
				<span class="navbar-caption-wrap"><a class="navbar-caption text-black display-4" href="../indix.php">NFTUniverse</a></span>
			</div>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<div class="hamburger">
					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</div>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav nav-dropdown" data-app-modern-menu="true">
					<li class="nav-item">
						<a class="nav-link link text-black display-4" href="../index.php">News</a>
					</li>
					<li class="nav-item">
						<a class="nav-link link text-black display-4" href="#" aria-expanded="false">content</a>
					</li>
					<li class="nav-item">
						<a class="nav-link link text-black display-4" href="#footer">Contacts</a>
					</li>
				</ul>
				<div class="navbar-buttons mbr-section-btn"><a class="btn btn-primary display-4" href="../inscription/inscription.php"> Start Now!</a></div>
			</div>
		</div>
	</nav>
</section>

<section data-bs-version="5.1" class="start article2 cid-u7tSZVmqGW" id="article02-2i">
<div class="col-12 content-head">
                            <div class="mbr-section-head mb-5">
                                <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-5"><strong>Explore Further with Our Recommended Topics :</strong></h4>
                            </div>
                        </div>
<?php
// Prepare the query to retrieve all subjects
$requete = "SELECT * FROM t_sujet_sjt;";
$result1 = $mysqli->query($requete);

// Check if the query executed successfully
if ($result1 === false) {
    die("Error executing query: " . $mysqli->error);
}

// Check if there are any rows returned
if ($result1->num_rows > 0) {
    // Loop through each subject
    while ($glr = $result1->fetch_assoc()) {
        // Output HTML for the subject
        ?>
        <section data-bs-version="5.1" class="start article2 cid-u7tSZVmqGW" id="article02-2i">
            <div class="container">
                <div class="row justify-content-center">
                 
                    <div class="col-12 col-md-12 col-lg">
                        <div class="text-wrapper align-left">
                            <h1 class="mbr-section-title mbr-fonts-style mb-4 display-5">
                                <strong><?php echo $glr['sjt_intitule']; ?></strong>
                            </h1>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

            <section data-bs-version="5.1" class="people03 cid-u7tUxvpHXO" id="people03-2j">
                <div class="container">
                    <div class="row justify-content-center">
                    </div>
                    <div class="row">
                    <?php
        // Fetch related fiches for this subject
        $id = $glr["sjt_id"];
        $requete1 = "SELECT * FROM t_fiche_fich WHERE sjt_id = '$id';";
        $result2 = $mysqli->query($requete1);

        // Check if the inner query executed successfully
        if ($result2 === false) {
            die("Error executing inner query: " . $mysqli->error);
        }

        // Check if there are any fiches returned
        if ($result2->num_rows > 0) {
            // Output HTML for fiches
            ?>
                        <?php
                        // Loop through each fiche
                        while ($glr2 = $result2->fetch_assoc()) {
                            ?>
                            <div class="item features-image col-12 col-md-6 col-lg-4">
                                <div class="item-wrapper">
                                    <div class="item-img mb-3">
                                        <!-- Display image for fiche if available -->
                                        <?php if (!empty($glr2["fic_image"])) { ?>
                                            <img src="images/<?php echo $glr2["fic_image"]; ?>" alt="picture" title="" width="200" height="200">
                                        <?php } ?>
                                    </div>
                                    <div class="item-content align-left">
                                        <h6 class="item-subtitle mbr-fonts-style mb-3 display-7"><?php echo $glr2['fic_label']; ?></h6>
                                        <div class="mbr-section-btn align-left mt-3"><a class="btn btn-success-outline display-7" href="fiche.php?fic_code=<?php echo $glr2['fic_code'];?>">Discover</a></div>
                                        <div class="mbr-section-btn align-left mt-3">
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </section>
            <?php
        } else {
            // If no fiches found, display a message
            ?>
            <section>
            <div class="container" style="color: red;">
            <figure class="text-center ">
                    <h3><strong>No fiches found  yet for this Topic.<strong></h3>
                    </figure>
                </div>
            </section>
            <?php
        }
    }
}

// Close database connection
$mysqli->close();
?>
</section><section class="display-7" style="padding: 0;align-items: center;justify-content: center;flex-wrap: wrap;    align-content: center;display: flex;position: relative;height: 4rem;"><a href="https://mobiri.se/2318866" style="flex: 1 1;height: 4rem;position: absolute;width: 100%;z-index: 1;"><img alt="" style="height: 4rem;" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="></a><p style="margin: 0;text-align: center;" class="display-7">&#8204;</p><a style="z-index:1" href="https://mobirise.com"> </a></section><script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>  <script src="assets/smoothscroll/smooth-scroll.js"></script>  <script src="assets/ytplayer/index.js"></script>  <script src="assets/dropdown/js/navbar-dropdown.js"></script>  <script src="assets/theme/js/script.js"></script>  
  
  </body>
</html>