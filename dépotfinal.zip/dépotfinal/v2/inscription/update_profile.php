
 <?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="#">Admine Page</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="try.php">Update</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="deconnection.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="#">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Interface</div>
                            <a class="nav-link collapsed" href="admin_accueil.php" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Gestionnement des Profiles
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <a class="nav-link collapsed" href="admin_act.php" >
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Gestionnement des Actualités
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <a class="nav-link" href="admin_sujets.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Gestionnement de Sujets et Fiches
                            </a>
                            <a class="nav-link" href="deconnection.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Déconnection
                            </a>
                        </div>
                    </div>
                
                </nav>
            </div>

            <div id="layoutSidenav_content">
                <main>
                <?php
                                        include('connection.php');
                                        $requete_verif_pfl = "SELECT * FROM t_profil_pfl WHERE cpt_pseudo='" . $_SESSION['login'] . "';";
                                    echo "</br>";
                                    if (!$resultat_verif_pfl = $mysqli->query($requete_verif_pfl)) {
                                        //La  requête a échoué
                                        echo "Error: Problème ! \n";
                                        echo "Error: " . $requete_verif_pfl . "\n";
                                        echo "Errno: " . $mysqli->errno . "\n";
                                        echo "Error: " . $mysqli->error . "\n";
                                        exit();
                                    } else {
                                        $ligne = $resultat_verif_pfl->fetch_assoc();
                                        ?>
                    <div class="container-fluid px-4" style="margin: left 150px;">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Bienvenue dans votre espace :  <strong><?php echo $ligne['pfl_nom']; ?></strong>  </li>
                        </ol>
 
                        <!---afficher les donnes  du profile-->
                                <div class="row">
                                    <div class="col-xl-6">
                                    <div id="page-wrapper" style="margin: left 150px;" >
                                        <div id="page-inner">
                                            <div class="row">
                                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-user me-1"></i>
                                    User Information
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Welcome <?php echo $ligne['pfl_nom']; ?></h5>
                                    <h6 class="card-subtitle mb-2 text-muted">Your Information:</h6>
                                    <p class="card-text">
                                        <strong>Name:</strong> <?php echo $ligne['pfl_nom']; ?><br>
                                        <strong>First Name:</strong> <?php echo $ligne['pfl_prenom']; ?><br>
                                        <strong>Username:</strong> <?php echo $ligne['cpt_pseudo']; ?><br>
                                        <strong>Status:</strong> <?php echo $ligne['pfl_statut']; ?>
                                    </p>
                                </div>
                            </div>
                            <div class="container">
                                <div class="alert alert-info" role="alert" >
                                    <strong>Note:</strong> Gestionnaire : G et Membre : M
                                </div>
                            </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
</main>
    <div id="layoutSidenav_content"> 
        <main>
            <h1>Update Profile</h1>
            <form action="" method="POST">
                <label for="pfl_nom">Last Name:</label>
                <input type="text" id="pfl_nom" name="pfl_nom" required><br><br>

                <label for="pfl_prenom">First Name:</label>
                <input type="text" id="pfl_prenom" name="pfl_prenom" required><br><br>

                <label for="cpt_pseudo">Username:</label>
                <input type="text" id="cpt_pseudo" name="cpt_pseudo" required><br><br>

                <label for="new_cpt_password">New Password:</label>
               <input type="password" id="new_cpt_password" name="new_cpt_password"><br><br>


                <input type="submit" value="Update Profile">
            </form>
            <?php
            // Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $pfl_nom = $_POST['pfl_nom'];
    $pfl_prenom = $_POST['pfl_prenom'];
    $cpt_pseudo = $_POST['cpt_pseudo'];
    $new_cpt_password = $_POST['new_cpt_password']; // New password

    // Update profile in the database
    $update_query = "UPDATE t_profil_pfl SET pfl_nom = '$pfl_nom', pfl_prenom = '$pfl_prenom'";
    
    // Check if new password is provided
    if (!empty($new_cpt_password)) {
        // Hash the new password
        $hashed_password = password_hash($new_cpt_password, PASSWORD_DEFAULT);
        // Add password update to the query
        $update_query .= ", cpt_password = '$hashed_password'";
    }
    
    // Add condition for specific user
    $update_query .= " WHERE cpt_pseudo = '$cpt_pseudo'";
    
    $update_result = $mysqli->query($update_query);

    if ($update_result) {
        // Profile updated successfully
        echo "<script>alert('Profile updated successfully');</script>";
        // Redirect back to update profile page
        header("Location: update_profile.php");
        exit;
    } else {
        // Error updating profile
        echo "<script>alert('Error updating profile');</script>";
        // Redirect back to update profile page
        header("Location: update_profile.php");
        exit;
    }
}
                                    }
                                
    // Fermeture de la communication avec la base MariaDB
$mysqli->close();
            ?>
        </main>
    </div>
</div>

<br><br><br><br><br>

<footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </footer>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
