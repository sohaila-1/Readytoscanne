<?php
/* Vérification ci-dessous à faire sur toutes les pages dont l'accès est
autorisé à un utilisateur connecté. */
// connection à la base de donner
include("connection.php");
session_start();
    if (! isset( $_SESSION[ 'login' ] ))
    {
        if (! isset( $_SESSION[ 'role' ] )) {
            //Si la session n'est pas ouverte, redirection vers la page du formulaire de connexion
            header( "Location:openning_session.php" );
        }
    }
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <style>
.container {
    margin-top: 20px;
}

.col-md-6 {
    border: 1px solid #ccc;
    padding: 10px;
    margin-bottom: 20px;
}
        </style>
    </head>

    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="admin_accueil.php">Admine Page</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="update_profile.php">Update</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="deconnection.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="admin_accueil.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Interface</div>
                             
                            <a class="nav-link" href="admin_accueil.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Gestionnement des Profiles
                            </a>
                            <a class="nav-link" href="admin_act.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Gestionnement des Actualités
                            </a>
                            <a class="nav-link" href="admin_sujets.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Gestionnement de Sujets et Fiches
                            </a>
                            <a class="nav-link" href="deconnection.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Déconnection
                            </a>
                        </div>
                    </div>
                
                </nav>
            </div>
            <!-- finish side bar -->

            <div id="layoutSidenav_content">
                <main>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Tables</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="admin_accueil.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Table de sujet</li>
                        </ol>
                        <div class="card mb-4">
                             
                        </div>
                        <div class="card mb-4">
                            <div class="card-header">
                                <div class="table-responsive">                                   
                                                
                                <div class="container">
                                <div class="card-body">

                        <?php
                        //connection à la base maria DB 
                        include('connection.php');
                        if ($_SESSION['role'] == 'G') {
                            echo '<div class="text-secondary mb-3"> <strong> Les sujets disponible pour le moment :</strong> </div>';
                            echo '<hr>';
                            // Fetch data from t_sujet_sjt table along with associated file names and creator 
                            $requete_sujet = "SELECT sjt.sjt_id, sjt.sjt_intitule, sjt.cpt_pseudo AS createur, GROUP_CONCAT(fch.fch_label SEPARATOR ', ') AS fiches_associees
                                                FROM t_sujet_sjt sjt
                                                LEFT JOIN t_fiche_fch fch ON sjt.sjt_id = fch.sjt_id
                                                GROUP BY sjt.sjt_id";
                        // requete pour extraire tous les sujets avec leur fiches associer 
                            $resultat_sujet = $mysqli->query($requete_sujet);
                            if ($resultat_sujet === false) {
                                // Error handling
                                echo "Error: La requête a échoué \n";
                                echo "Errno: " . $mysqli->errno . "\n";
                                echo "Error: " . $mysqli->error . "\n";
                                exit();
                            }

// Check if the form for deleting a subject has been submitted
if (isset($_POST['supprimer']) && isset($_POST['sujet_id'])) {
    $sujet_id = $_POST['sujet_id'];

    // Supprimer d'abord les enregistrements enfants dans la table t_fiche_fch
    $requete_supprimer_fiches = "DELETE FROM t_fiche_fch WHERE sjt_id = $sujet_id";
    $resultat_supprimer_fiches = $mysqli->query($requete_supprimer_fiches);

    if ($resultat_supprimer_fiches === false) {
        echo "Error: La suppression des fiches associées a échoué \n";
        echo "Errno: " . $mysqli->errno . "\n";
        echo "Error: " . $mysqli->error . "\n";
    } else {
        // Ensuite, supprimer l'enregistrement parent dans la table t_sujet_sjt
        $requete_supprimer_sujet = "DELETE FROM t_sujet_sjt WHERE sjt_id = $sujet_id";
        $resultat_supprimer_sujet = $mysqli->query($requete_supprimer_sujet);
        
        if ($resultat_supprimer_sujet === false) {
            echo "Error: La suppression du sujet a échoué \n";
            echo "Errno: " . $mysqli->errno . "\n";
            echo "Error: " . $mysqli->error . "\n";
        } else {
            echo '<script>alert("Le sujet et ses fiches ont été supprimés avec succès.")</script>';
        }
    }
}

                            // Display the table
                            echo '<table class="table table-striped">';
                            echo '<tr><th>Sujet</th><th>Créateur</th><th>Fiches Associées</th><th>Actions</th></tr>';

                            while ($sujet = $resultat_sujet->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>' . $sujet['sjt_intitule'] . '</td>';
                                echo '<td>' . $sujet['createur'] . '</td>';
                                echo '<td>';
                                // Display files as an unordered list if any
                                if (!empty($sujet['fiches_associees'])) {
                                    echo '<ul>';
                                    $fiches = explode(", ", $sujet['fiches_associees']);
                                    foreach ($fiches as $fiche) {
                                        echo '<li>' . $fiche . '</li>';
                                    }
                                    echo '</ul>';
                                } else {
                                    echo 'Aucune fiche associée';
                                }
                                echo '</td>';
                                echo '<td><form method="POST">';
                                echo '<input type="hidden" name="sujet_id" value="' . $sujet['sjt_id'] . '">';
                                echo '<button type="submit" class="btn btn-danger" name="supprimer">Supprimer</button>';
                                echo '</form></td>';
                                echo '</tr>';
                            }
                            echo '</table>';
                        } else {
                            echo "<div class='display-4 mb-4'>";
                            echo "<div class='text-primary'>";
                            echo "<h3>Vous êtes Membre ! vous pouvez ajouter un sujet </h3> ";
                            echo "</div>";
                            echo "</div>";
                        }
                        ?>
 <?php
// Include the database connection
include('connection.php');

// Start the session if not started already
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and the 'role' and 'login' keys are set in the session
if (!isset($_SESSION['login']) || !isset($_SESSION['role'])) {
    // If the session is not open, redirect to the login page
    header("Location: openning_session.php");
    exit; // Terminate script execution after redirection
}

// Check if the user has the appropriate role to add a topic
if ($_SESSION['role'] == 'M') {
    // Check if the add topic form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['ajouter'])) {
        // Retrieve form data
        $sjt_intitule = $_POST['sjt_intitule'];
        $cpt_pseudo = $_SESSION['login']; // Use the username of the logged-in user as the creator

        // Get the current datetime
        $sjt_date = date('Y-m-d H:i:s');

        // Prepare the SQL query for insertion
        $requete_ajouter_sujet = "INSERT INTO t_sujet_sjt (sjt_intitule, sjt_date, cpt_pseudo) VALUES (?, ?, ?)";

        // Prepare the SQL statement
        $stmt = $mysqli->prepare($requete_ajouter_sujet);

        // Bind parameters
        $stmt->bind_param("sss", $sjt_intitule, $sjt_date, $cpt_pseudo);

        // Execute the statement
        if ($stmt->execute()) {
            // Success message
            echo '<script>alert("Le sujet a été ajouté avec succès.")</script>';
        } else {
            // Error message
            echo '<script>alert("Une erreur s\'est produite lors de l\'ajout du sujet: ' . $mysqli->error . '")</script>';
        }

        // Close the statement
        $stmt->close();
    }

    // Display the add topic form
    echo '<form method="POST">';
    echo '<div class="form-group" >';
    echo '<br>';
    echo '<label for="sjt_intitule"><strong>Intitulé du sujet ajouté:</strong></label>';
    echo '<br><br>';
    echo '<input type="text" class="form-control" id="sjt_intitule" name="sjt_intitule" required>';
    echo '</div>';
    echo '<br>';
    echo '<button type="submit" class="btn btn-danger" name="ajouter">Ajouter le sujet</button>';
    echo '<span style="margin: 0 10px;"></span>';
    echo'<a href="../recapitulative/repertoir.php" class="btn btn-success">Vérifier</a>';
    echo '</form>';
    
} else {
    // If the user does not have the appropriate role to add a topic
    echo "<div class='display-4 mb-4'>";
    echo "<div class='text-primary'>";
    echo "<h4>Vous n'êtes pas autorisé à ajouter un sujet.</h4>";
    echo "</div>";
    echo "</div>";
}

// Close the database connection
$mysqli->close();
?>

                         </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
