-- 1. Insérez un compte puis le profil associé en une seule manipulation
INSERT INTO t_compte_cpt (cpt_pseudo, cpt_password) VALUES ('nouveau_user', 'mot_de_passe');
INSERT INTO t_profil_pfl (cpt_pseudo, pfl_nom, pfl_prenom, pfl_validite, pfl_statut) VALUES ('nouveau_user', 'NomUser', 'PrenomUser', 'Y', 'A');

-- 2. Modifiez la validité d'un profil connaissant le pseudo de l'utilisateur
UPDATE t_profil_pfl SET pfl_validite = 'A' WHERE cpt_pseudo = 'pseudo_utilisateur';

-- 3. Supprimez une ligne de la table des profils connaissant le pseudo d'un utilisateur
DELETE FROM t_profil_pfl WHERE cpt_pseudo = 'pseudo_utilisateur';

-- 4. a) Listez tous les noms, prénoms et statuts des utilisateurs suivant l'ordre alphabétique des noms de famille
SELECT pfl_nom, pfl_prenom, pfl_statut FROM t_profil_pfl ORDER BY pfl_nom;

-- 4. b) Listez tous les noms, prénoms et statuts des utilisateurs rassemblés par statut
SELECT pfl_nom, pfl_prenom, pfl_statut FROM t_profil_pfl ORDER BY pfl_statut, pfl_nom;

-- 5. Listez tous les noms, prénoms et pseudo (@email) des utilisateurs de statut 'M' (Membre) dans l'ordre alphabétique décroissant des prénoms
SELECT pfl_nom, pfl_prenom, cpt_pseudo FROM t_profil_pfl WHERE pfl_statut = 'M' ORDER BY pfl_prenom DESC;

--- 6
select cpt_pseudo, new_titre, new_date from t_news_new where new_date > '01-01-2023';
select cpt_pseudo, new_titre, new_date from t_news_new  where new_date > '01-01-2023' or new_date <'01-01-2024';
-- actualite ajouter entre 2023 et 2024
select cpt_pseudo, new_titre, new_date from t_news_new  where new_date > '01-01-2023' and new_date <'01-01-2024';

---7----
INSERT INTO t_compte_cpt (cpt_pseudo, cpt_mdp) VALUES ('kg@g.com', MD5('tch56bFziDrK'));
insert into t_profile_pfl (pfl_prenom, pfl_nom, pfl_role, pfl_validite, pfl_date, cpt_pseudo) values ('Lex', 'Cck', 'A', 'V', NOW()  , 'kg@g.com');
---8----
select count(fch_id) from t_fiche_fch order by fic_id
select fic_id from t_fiche_fch order by fic_id limit 1
---9---
select * from t_profil_pfl where date between('2021-08-01') and date('2021-08-31');

---10---
select count(pfl_statut) as nb memebres from t_profil_pfl where pfl_statut='M' ; 
select count(pfl_statut) as nb gestionnaire from t_profil_pfl where pfl_statut='G' ; 
---11---
select fic_etat from  t_fichier_fic  ;
---12---
 Donnez la requête permettant de vérifier qu'un pseudo et le mot de passe
SELECT COUNT(*) FROM t_compte_cpt c INNER JOIN t_profil_pfl p ON c.cpt_pseudo=p.cpt_pseudo AND c.cpt_password=MD5(p.cpt_password) WHERE p. ; 
