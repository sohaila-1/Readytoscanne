-- phpMyAdmin SQL Dump
-- version 5.0.4deb2+deb11u1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 17, 2024 at 10:19 PM
-- Server version: 10.5.19-MariaDB-0+deb11u2-log
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e22111152_db1`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_compte_cpt`
--

CREATE TABLE `t_compte_cpt` (
  `cpt_pseudo` varchar(60) NOT NULL,
  `cpt_password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_compte_cpt`
--

INSERT INTO `t_compte_cpt` (`cpt_pseudo`, `cpt_password`) VALUES
('amer.jebbawi123@gmail.com', 'd32a68178250b91c4f03a511bca5e9b7'),
('amine@gmail.com', '3618e0d65b8f8e564922011fe5b83fd1'),
('etudiant1@universite.fr', '9e506478b77e43f3ff333c246f85abdc'),
('etudiant2@universite.fr', 'd3dbf245cba55977b99586417811abc9'),
('gestionnaire1@NFTU.fr', 'd1c7dd460b0ab4887399c1ae45f6c6b1'),
('ines@univ.fr', 'e559744627cceb9d06579d548b57bc01'),
('medi@gmail.com', 'e459aabdc1dfcdf8437f997356030711'),
('mery@univ.fr', '4124bc0a9335c27f086f24ba207a4912'),
('mounir@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710'),
('personnel1@universite.fr', '8c8bfb0391476c9f9a985b5d3ab5136c'),
('personnel2@universite.fr', '6bd812674a92fe1fe6d3b91d059c291c'),
('primelisa@gmail.com', '3691308f2a4c2f6983f2880d32e29c84'),
('souhailanachafi@gmail.com', '5e36941b3d856737e81516acd45edc50'),
('wiam@univ.fr', '82a9e4d26595c87ab6e442391d8c5bba'),
('zz@gmail.com', '25ed1bcb423b0b7200f485fc5ff71c8e');

-- --------------------------------------------------------

--
-- Table structure for table `t_fiche_fch`
--

CREATE TABLE `t_fiche_fch` (
  `fch_id` int(11) NOT NULL,
  `fch_label` varchar(50) NOT NULL,
  `fch_contenu` varchar(600) NOT NULL,
  `fch_image` varchar(100) NOT NULL,
  `fch_code` char(12) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `fch_statut` char(1) NOT NULL,
  `sjt_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_fiche_fch`
--

INSERT INTO `t_fiche_fch` (`fch_id`, `fch_label`, `fch_contenu`, `fch_image`, `fch_code`, `fch_statut`, `sjt_id`) VALUES
(10, 'The merge', 'Une œuvre entièrement numérique de l’artiste américain Beeple a été vendue, jeudi 11 mars, 69,3 millions de dollars (57,8 millions d’euros) par la maison d’enchères Christie’s, un record qui témoigne de la révolution en cours sur ce marché longtemps confidentiel.', '1.png', '6aP7tRbE9Qz2', 'P', 1),
(11, 'Everydays : the First 5 000 Days', 'Une œuvre entièrement numérique de l’artiste américain Beeple a été vendue, jeudi 11 mars, 69,3 millions de dollars (57,8 millions d’euros) par la maison d’enchères Christie’s, un record qui témoigne de la révolution en cours sur ce marché longtemps confidentiel', '3.png', '5sN8jK2rVhLp', 'P', 1),
(12, 'The merge by pack', 'Singular in its creation, it was conceived to bring together 266,445 digital units, the total merger of which would form a single work. Thus, the 28,984 buyers of these 266,445 units received on Monday, December 6th, an NFT composed of each of the units purchased in the sale, the entirety of which would give rise to the final piece: The Merge.', '2.png', 'A4bR6gS1eYqW', 'P', 1),
(19, 'Collection Nft of  Caracteres', 'The first 5000 days', '4.png', '7tP9dF2cVxJm', 'P', 2),
(20, 'Collection Nft of  Caracteres', 'Nefertiti, a digital creation by Coralie Honnorat, is a captivating and intricate piece of digital art. Inspired by the iconic Egyptian queen, Nefertiti, this artwork embodies a fusion of traditional elegance and modern digital techniques. Honnorat\'s rendition captures the essence of Nefertiti\'s beauty and power, presenting her in a unique and contemporary light. Through meticulous attention to detail and creative innovation.\r\n\r\n', '5.jpg', '3zX8mN1wQbVc', 'P', 2),
(21, 'Collection Nft of  Caracteres', ' NFTs Toys for kids 10\" appears to be a collection or series of non-fungible tokens (NFTs) specifically designed for children. These digital tokens likely represent various types of toys or playful characters that children can engage with in the digital realm. Each NFT within this collection could depict a different toy, ranging from teddy bears to action figures to cartoon characters, providing a fun and interactive experience for young users in the digital space', '6.jpg', '2dH7rT4nGpWk', 'P', 2),
(22, 'LE BORED APE 1', 'Price: $3,408,000', '7.png', '9vC5xM3qB2nL', 'P', 3),
(23, 'LE BORED APE 2', 'Price: $2.9 million', '8.png', 'J6fR3sW8qZmX', 'P', 3),
(24, 'LE BORED APE 3', 'Price: $2.8 million', '9.png', 'T9kY2vN5bHcP', 'P', 3);

-- --------------------------------------------------------

--
-- Table structure for table `t_hyperlien_hpl`
--

CREATE TABLE `t_hyperlien_hpl` (
  `hpl_id` int(11) NOT NULL,
  `hpl_nom` varchar(255) NOT NULL,
  `hpl_url` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_hyperlien_hpl`
--

INSERT INTO `t_hyperlien_hpl` (`hpl_id`, `hpl_nom`, `hpl_url`) VALUES
(1, 'More detail aboute the merge', 'https://luxe.net/the-merge-by-pak-le-nouveau-record-de-ventes-aux-encheres-nft-senvole-a-918-millions-de-dollars/'),
(2, 'Everydays : the First 5 000 Days', 'https://www.lemonde.fr/culture/article/2021/03/11/une-uvre-numerique-se-vend-69-3-millions-de-dollars-chez-christie-s-un-record_6072801_3246.html'),
(3, 'The Merge - sold for $91.8 million dollars', 'https://www.lemediadelinvestisseur.fr/cryptomonnaies/nft-le-plus-cher/#:~:text=L\'%C5%93uvre%20%E2%80%9CThe%20Merge%E2%80%9D,juste%20avant%20%E2%80%9CThe%20Merge%E2%80%9D.'),
(4, 'Pixels & NFT For characters animé', 'https://mintable.com/art/item/Nefertiti-by-Coralie-HONNORAT-Mintable-Shared-Store/0x2880c6ecf2f770bd31ddb0d776cc81048899b600:55390780318319843688885446272384815151513561206622931878730940737750284141697\r\n'),
(5, 'Pixels & NFT for characters', 'https://www.artsper.com/fr/oeuvres-d-art-contemporain/photographie/1138359/toys-for-kids-10-very-rare-first-nft-model\r\n'),
(6, 'Pixels & NFT\'s', 'https://pixelcorner.fr/blogs/infos/pixels-nft\r\n'),
(7, 'Tableux dezeen\r\n', 'https://www.dezeen.com/2021/03/12/beeple-everydays-nft-christies-auction/');

-- --------------------------------------------------------

--
-- Table structure for table `t_liaison_lsn`
--

CREATE TABLE `t_liaison_lsn` (
  `hpl_id` int(11) NOT NULL,
  `fch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_liaison_lsn`
--

INSERT INTO `t_liaison_lsn` (`hpl_id`, `fch_id`) VALUES
(1, 11),
(1, 12),
(2, 10),
(2, 12),
(2, 21),
(3, 10),
(3, 11),
(4, 20),
(4, 21),
(6, 10),
(6, 19),
(6, 20),
(7, 11);

-- --------------------------------------------------------

--
-- Table structure for table `t_news_new`
--

CREATE TABLE `t_news_new` (
  `new_id` int(11) NOT NULL,
  `new_titre` varchar(80) NOT NULL,
  `new_date` date NOT NULL,
  `new_description` text NOT NULL,
  `new_etat` char(1) NOT NULL,
  `cpt_pseudo` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_news_new`
--

INSERT INTO `t_news_new` (`new_id`, `new_titre`, `new_date`, `new_description`, `new_etat`, `cpt_pseudo`) VALUES
(21, 'Les NFTs dans la finance', '2024-02-16', 'Découvrez comment les NFTs transforment l\'industrie financière et la tokenisation des actifs', 'P', 'wiam@univ.fr'),
(22, 'L\'impact environnemental des NFTs', '2024-02-06', 'Explorez les préoccupations croissantes concernant la consommation énergétique', 'P', 'personnel1@universite.fr'),
(39, 'L\'impact des NFTs sur le marché de l\'art', '2024-02-29', 'Les NFTs (Tokens Non Fongibles) ont transformé le marché de l\'art en permettant la vente et l\'échange d\'œuvres numériques uniques, créant ainsi de nouvelles perspectives pour les artistes et les collectionneurs.', 'C', 'mounir@gmail.com'),
(40, 'Les applications des NFTs dans l\'industrie du divertissement', '2024-02-29', 'Les NFTs sont de plus en plus utilisés dans l\'industrie du divertissement, notamment dans les jeux vidéo, la musique et le cinéma, offrant de nouvelles façons de monétiser et de distribuer du contenu.', 'P', 'mery@univ.fr'),
(41, 'L\'avenir de la tokenisation des actifs réels', '2024-02-29', 'La tokenisation des actifs réels, tels que l\'immobilier et les œuvres d\'art, est un domaine en pleine croissance qui suscite un intérêt croissant de la part des investisseurs et des régulateurs.', 'C', 'medi@gmail.com'),
(42, 'L\'impact des NFTs sur la propriété intellectuelle', '2024-02-29', 'Les NFTs soulèvent des questions complexes en matière de propriété intellectuelle et de droits d\'auteur, ce qui nécessite une réflexion approfondie sur la manière dont ces actifs numériques uniques sont créés, échangés et protégés.', 'P', 'wiam@univ.fr'),
(43, 'L\'utilisation des NFTs dans les jeux vidéo', '2024-02-29', 'Les NFTs sont de plus en plus intégrés dans les jeux vidéo, offrant aux joueurs la possibilité de posséder et de monétiser des objets virtuels uniques, ce qui transforme l\'économie des jeux en ligne.', 'P', 'wiam@univ.fr'),
(44, 'Les implications juridiques des NFTs', '2024-02-29', 'Les NFTs posent des défis juridiques complexes en matière de propriété, de responsabilité et de fiscalité, nécessitant une réglementation adaptée pour protéger les créateurs et les investisseurs.', 'P', 'primelisa@gmail.com'),
(45, 'L\'évolution des plateformes de NFTs', '2024-02-29', 'Les plateformes de NFTs évoluent rapidement pour répondre aux besoins croissants des créateurs et des acheteurs, introduisant de nouvelles fonctionnalités et normes pour garantir la sécurité et la facilité d\'utilisation.', 'P', 'personnel2@universite.fr'),
(46, 'L\'utilisation des NFTs dans l\'industrie musicale', '2024-02-29', 'Les NFTs transforment l\'industrie musicale en permettant aux artistes de monétiser leur musique de manière innovante, tout en offrant aux fans des expériences uniques et exclusives.', 'C', 'wiam@univ.fr'),
(49, 'L\'utilisation des NFTs dans l\'éducation', '2024-02-29', 'Les NFTs sont explorés comme outils pédagogiques dans l\'éducation, offrant de nouvelles façons d\'encourager l\'apprentissage, la collaboration et la propriété intellectuelle des étudiants.', 'C', 'primelisa@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `t_profil_pfl`
--

CREATE TABLE `t_profil_pfl` (
  `cpt_pseudo` varchar(60) NOT NULL,
  `pfl_nom` varchar(60) NOT NULL,
  `pfl_prenom` varchar(60) NOT NULL,
  `pfl_validite` char(1) NOT NULL,
  `pfl_statut` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_profil_pfl`
--

INSERT INTO `t_profil_pfl` (`cpt_pseudo`, `pfl_nom`, `pfl_prenom`, `pfl_validite`, `pfl_statut`) VALUES
('amer.jebbawi123@gmail.com', 'Amer', 'EL JIBBAWE', 'D', 'M'),
('amine@gmail.com', 'amine', 'amine', 'A', 'M'),
('etudiant1@universite.fr', 'Smith', 'John', 'A', 'M'),
('etudiant2@universite.fr', 'Brown', 'Emma', 'A', 'M'),
('gestionnaire1@NFTU.fr', 'valerie', 'marc', 'A', 'G'),
('ines@univ.fr', 'ines', 'innes', 'D', 'M'),
('medi@gmail.com', 'Mehdi', 'Nachafi', 'D', 'M'),
('mery@univ.fr', 'mery', 'meryem', 'A', 'M'),
('mounir@gmail.com', 'mehamdi', 'mounir', 'D', 'M'),
('personnel1@universite.fr', 'Taylor', 'Alex', 'D', 'M'),
('personnel2@universite.fr', 'Clark', 'Sophie', 'A', 'M'),
('primelisa@gmail.com', 'prime', 'lisa', 'D', 'M'),
('souhailanachafi@gmail.com', 'nachafi', 'Sohaila', 'D', 'M'),
('wiam@univ.fr', 'alaoui', 'wiam', 'D', 'M'),
('zz@gmail.com', 'zz', 'zz', 'A', 'M');

-- --------------------------------------------------------

--
-- Table structure for table `t_sujet_sjt`
--

CREATE TABLE `t_sujet_sjt` (
  `sjt_id` int(11) NOT NULL,
  `sjt_intitule` varchar(50) NOT NULL,
  `sjt_date` datetime NOT NULL,
  `cpt_pseudo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_sujet_sjt`
--

INSERT INTO `t_sujet_sjt` (`sjt_id`, `sjt_intitule`, `sjt_date`, `cpt_pseudo`) VALUES
(1, 'The Merge - sold for $91.8 million dollars', '2025-07-02 00:00:00', 'etudiant2@universite.fr'),
(2, ' Everydays : NFT ART -NFT characters', '2024-02-19 00:00:00', 'souhailanachafi@gmail.com'),
(3, 'Characters ', '2024-04-15 00:00:00', 'gestionnaire1@NFTU.fr'),
(4, 'Topic 4', '2024-03-11 00:00:00', 'etudiant1@universite.fr'),
(22, 'test1', '2024-04-17 15:00:31', 'gestionnaire1@NFTU.fr');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_compte_cpt`
--
ALTER TABLE `t_compte_cpt`
  ADD PRIMARY KEY (`cpt_pseudo`);

--
-- Indexes for table `t_fiche_fch`
--
ALTER TABLE `t_fiche_fch`
  ADD PRIMARY KEY (`fch_id`),
  ADD KEY `sjt_id` (`sjt_id`);

--
-- Indexes for table `t_hyperlien_hpl`
--
ALTER TABLE `t_hyperlien_hpl`
  ADD PRIMARY KEY (`hpl_id`);

--
-- Indexes for table `t_liaison_lsn`
--
ALTER TABLE `t_liaison_lsn`
  ADD PRIMARY KEY (`hpl_id`,`fch_id`),
  ADD KEY `fch_id` (`fch_id`);

--
-- Indexes for table `t_news_new`
--
ALTER TABLE `t_news_new`
  ADD PRIMARY KEY (`new_id`),
  ADD KEY `cpt_pseudo` (`cpt_pseudo`);

--
-- Indexes for table `t_profil_pfl`
--
ALTER TABLE `t_profil_pfl`
  ADD PRIMARY KEY (`cpt_pseudo`);

--
-- Indexes for table `t_sujet_sjt`
--
ALTER TABLE `t_sujet_sjt`
  ADD PRIMARY KEY (`sjt_id`),
  ADD KEY `cpt_pseudo` (`cpt_pseudo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_fiche_fch`
--
ALTER TABLE `t_fiche_fch`
  MODIFY `fch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `t_hyperlien_hpl`
--
ALTER TABLE `t_hyperlien_hpl`
  MODIFY `hpl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `t_news_new`
--
ALTER TABLE `t_news_new`
  MODIFY `new_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `t_sujet_sjt`
--
ALTER TABLE `t_sujet_sjt`
  MODIFY `sjt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_fiche_fch`
--
ALTER TABLE `t_fiche_fch`
  ADD CONSTRAINT `t_fiche_fch_ibfk_1` FOREIGN KEY (`sjt_id`) REFERENCES `t_sujet_sjt` (`sjt_id`);

--
-- Constraints for table `t_liaison_lsn`
--
ALTER TABLE `t_liaison_lsn`
  ADD CONSTRAINT `t_liaison_lsn_ibfk_1` FOREIGN KEY (`hpl_id`) REFERENCES `t_hyperlien_hpl` (`hpl_id`),
  ADD CONSTRAINT `t_liaison_lsn_ibfk_2` FOREIGN KEY (`fch_id`) REFERENCES `t_fiche_fch` (`fch_id`);

--
-- Constraints for table `t_news_new`
--
ALTER TABLE `t_news_new`
  ADD CONSTRAINT `t_news_new_ibfk_1` FOREIGN KEY (`cpt_pseudo`) REFERENCES `t_compte_cpt` (`cpt_pseudo`);

--
-- Constraints for table `t_profil_pfl`
--
ALTER TABLE `t_profil_pfl`
  ADD CONSTRAINT `t_profil_pfl_ibfk_1` FOREIGN KEY (`cpt_pseudo`) REFERENCES `t_compte_cpt` (`cpt_pseudo`) ON DELETE CASCADE;

--
-- Constraints for table `t_sujet_sjt`
--
ALTER TABLE `t_sujet_sjt`
  ADD CONSTRAINT `t_sujet_sjt_ibfk_1` FOREIGN KEY (`cpt_pseudo`) REFERENCES `t_compte_cpt` (`cpt_pseudo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
