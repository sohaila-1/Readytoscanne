    --Donnez la requête permettant de vérifier qu'un pseudo et le mot de passe
associé existent dans la base de données et sont associés à un profil activé
(‘A’). A quoi sert cette requête ?--
SELECT * FROM t_compte_cpt JOIN t_profil_pfl USING(cpt_pseudo) WHERE pfl_validite='A' ; 

----requete 13--
Supprimez toutes les données de l’utilisateur de pseudo « mdurand@univbrest.fr ». Que faut-il faire si cet utilisateur a ajouté des sujets / actualités ?
 
    DELETE FROM `t_actualite_act` WHERE cpt_pseudo=' mdurand@univbrest.fr';
    DELETE FROM `t_sujet_sjt` WHERE cpt_pseudo=' mdurand@univbrest.fr';
    DELETE FROM `t_compte_cpt` WHERE cpt_pseudo=' mdurand@univbrest.fr';
    DELETE FROM `t_profil_pfl` WHERE cpt_pseudo=' mdurand@univbrest.fr';
    La requête ci-dessus supprime les enregistrements correspondants au pseudo 'mdurand@univbrest.fr' de toutes les tables qui contiennent

---requete 14---
Proposez une requête permettant de vérifier s’il y a bien autant de comptes que de
profils dans la base de données?

SELECT
    (SELECT COUNT(*) FROM t_compte_cpt) AS nb_comptes,
    (SELECT COUNT(*) FROM t_profil_pfl) AS nb_profils;

---requete 15---
DELETE FROM t_compte_cpt
WHERE cpt_pseudo NOT IN (SELECT cpt_pseudo FROM t_profil_pfl)
AND cpt_pseudo NOT IN (SELECT DISTINCT cpt_pseudo FROM t_actualite_act)
AND cpt_pseudo NOT IN (SELECT DISTINCT cpt_pseudo FROM t_sujet_sjt)
AND cpt_pseudo NOT IN (SELECT DISTINCT cpt_pseudo FROM t_fiche_fich);

---requete 16 Bonus ---
SELECT c.cpt_pseudo, s.sjt_intitule AS sujet, f.fic_contenu AS contenu_fiche, h.hyp_url AS lien_hyperlien FROM t_compte_cpt c 
    LEFT JOIN t_profil_pfl p ON c.cpt_pseudo = p.cpt_pseudo
    LEFT JOIN t_sujet_sjt s ON c.cpt_pseudo = s.cpt_pseudo 
    LEFT JOIN t_fiche_fich f ON s.sjt_id = f.sjt_id
    LEFT JOIN t_hyperlien_hyp h ON f.fic_numero = h.fic_numero; 
    



