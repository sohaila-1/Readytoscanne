element de connection à obiwan 
phpmyadmine : https://obiwan.univ-brest.fr/phpmyadmin/index.php
username : e22111152sql
mdp : 9q!#gus0
base de données : e22111152_db1

website for QRcodes : https://qr.io/dashboard/

## Sujet : "Exploration Virtuelle des Campus Universitaires" ##
Description : L'application "Ready2Scan" sera conçue pour permettre aux visiteurs, étudiants et nouveaux arrivants de découvrir virtuellement les campus universitaires. Les QR codes seront associés à des points d'intérêt spécifiques, fournissant des informations détaillées sur les département de chaque filière 

colors :
#0d6efd;  /* blue */
#fee84b;   /* yellow */