<?php
 require "connection/connection.php";
 ?>

<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.9.17, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.9.17, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logo.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Home</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/parallax/jarallax.css">
  <link rel="stylesheet" href="assets/animatecss/animate.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Inter+Tight:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter+Tight:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css?v=edgumZ"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css?v=edgumZ" type="text/css">

  
  <style>
  /* Custom CSS for table styling */
.table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 20px;
}

.table th, .table td {
    padding: 8px;
    text-align: left;
}

.table th {
    background-color: black;
    color: #fff;
}

.table td {
    border-bottom: 1px solid #dee2e6;
}

.table tbody tr:hover {
    background-color: #c9c9c9;
}

/* Adjusting column widths */
.table th:nth-child(1),
.table td:nth-child(1) {
    width: 25%;
}

.table th:nth-child(2),
.table td:nth-child(2) {
    width: 40%;
}

.table th:nth-child(3),
.table td:nth-child(3) {
    width: 15%;
}

.table th:nth-child(4),
.table td:nth-child(4) {
    width: 20%;
}

</style>
  
</head>
<body>
  
  <section data-bs-version="5.1" class="menu menu2 cid-u94GECXhPR" once="menu" id="menu02-2s">
	

	<nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
		<div class="container">
			<div class="navbar-brand">
				
				<span class="navbar-caption-wrap"><a class="navbar-caption text-black display-4" href="#">NFTUniverse</a></span>
			</div>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<div class="hamburger">
					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</div>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
						<a class="nav-link link text-black display-4" href="index.php#new1">News</a>
					</li>
					<li class="nav-item">
						<a class="nav-link link text-black display-4" href="recapitulative/repertoir.php" aria-expanded="false">Content</a>
					</li>
					<li class="nav-item">
						<a class="nav-link link text-black text-primary display-4" href="index.php#footer02-2q">Contacts</a>
					</li></ul>
				<div class="navbar-buttons mbr-section-btn"><a class="btn btn-info display-4" href="inscription/inscription.php"> Sign Up</a></div>
        <span style="margin: 0 10px;"></span>
        <div class="navbar-buttons mbr-section-btn"><a class="btn btn-info display-4" href="inscription/opening_session.php"> Sign In</a></div>
			</div>
		</div>
	</nav>
</section>

<section data-bs-version="5.1" class="header16 cid-u73gdV7W0Y mbr-fullscreen mbr-parallax-background" id="header17-1m">
  
  
  <div class="container-fluid">
    <div class="row">
      <div class="content-wrap col-12 col-md-12">
        <h1 class="mbr-section-title mbr-fonts-style mbr-white mb-4 display-1">
          <br><strong>Discover &amp; Collect&nbsp;</strong><br><strong>Amazing NFTs</strong></h1>
        
        <p class="mbr-fonts-style mbr-text mbr-white mb-4 display-7">Explore an eclectic collection of unique NFTs, showcasing the creativity of artists and creators from around the globe.</p>
        <div class="mbr-section-btn"><a class="btn btn-white-outline display-7" href="index.html#features016-1o">Learn More</a></div>
      </div>
    </div>
  </div>
</section>

<section data-bs-version="5.1" class="features16 cid-u73kkA0ltB" id="features016-1o">  
  
  
  
  <div class="container">
    <div class="row justify-content-center mb-5">
      <div class="col-12 content-head">
        <h5 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
          <strong>Content : </strong>
        </h5>
        
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="item features-without-image col-12 col-lg-4">
        <div class="item-wrapper">
          <div class="card-box">
            <div class="img-box">
              <div class="image-wrapper mb-3">
                <img src="assets/images/1.png" alt="">
              </div>
              <?php
                        // Exécution de la requête SQL pour compter le nombre de sujets
                        $sql_count = "SELECT COUNT(*) AS total_sujets FROM t_sujet_sjt";
                        $result_count = $mysqli->query($sql_count);
                        $row_count = $result_count->fetch_assoc();
                        ?>
            </div>
            <h4 class="card-title mbr-fonts-style mb-0 display-7"><strong><?php echo $row_count['total_sujets']; ?> Subjects&nbsp;</strong></h4>
            <h5 class="card-text mbr-fonts-style mt-3 display-7">Dive into diverse NFT topics.&nbsp; .
            </h5>
            <div class="link-wrap">
              
            </div>
          </div>
        </div>
      </div>
      <div class="item features-without-image col-12 col-lg-4">
        <div class="item-wrapper">
          <div class="card-box">
            <div class="img-box">
              <div class="image-wrapper mb-3">
                <img src="assets/images/2.png" alt="Mobirise Website Builder">
              </div>
              <?php
                        // Exécution de la requête SQL pour compter le nombre de fiches
                        $sql_count_fiches = "SELECT COUNT(*) AS total_fiches FROM t_fiche_fch";
                        $result_count_fiches = $mysqli->query($sql_count_fiches);
                        $row_count_fiches = $result_count_fiches->fetch_assoc();
                        ?>
            </div>
            <h4 class="card-title mbr-fonts-style mb-0 display-7"><strong><?php echo $row_count_fiches['total_fiches']; ?> Cards&nbsp;</strong></h4>
            <h5 class="card-text mbr-fonts-style mt-3 display-7">&nbsp;In-depth NFT topics on cards.&nbsp;</h5>
            <div class="link-wrap">
              
            </div>
          </div>
        </div>
      </div>
      
    </div>
  </div>
</section>
<!--------- end of showing les indicateurs ------------>
<!--------- end of showing les indicateurs ------------>
<br><br><br>
<!------start of table of the Subjects ------->
<div class="container">
    <h5 class="mbr-section-title mbr-fonts-style align-center mb-4 display-2" style="color:#320707" id="new1">
        <strong>Actualities:</strong>
    </h5>
    
    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="thead-dark">
                <tr>
                    <th style="width: 25%;">Titre d'actualité</th>
                    <th style="width: 40%;">Description</th>
                    <th style="width: 15%;">Date de publication</th>
                    <th style="width: 20%;">L'auteur</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT new_titre, new_description, new_date, cpt_pseudo FROM t_news_new LIMIT 4";
                $result = $mysqli->query($sql);
                // Vérifiez si des résultats ont été retournés
                if ($result->num_rows > 0) {
                    // Boucle à travers les résultats
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>".$row["new_titre"]."</td>";
                        echo "<td>".$row["new_description"]."</td>";
                        echo "<td>".$row["new_date"]."</td>";
                        echo "<td>".$row["cpt_pseudo"]."</td>";
                        echo "</tr>";
                    }
                } else {
                    // Aucune actualité trouvée
                    echo "<tr><td colspan='4'>Aucune actualité trouvée</td></tr>";
                }
                // Close the database connection
$mysqli->close();
                ?>
            </tbody>
        </table>
    </div>
</div>
<br><br><br><br><br><br><br><br>
<section data-bs-version="5.1" class="footer2 cid-u94GuzcVHW" once="footers" id="footer02-2q">

    <div class="container">
        <div class="row flex-row-reverse">
            <div class="col-12 col-lg-6 center mt-2 mb-3">
                <p class="mbr-fonts-style copyright mb-0 display-7">
                    <strong> Opening Hours : <br> Monday to Friday 9:00AM - 7AM </strong>
                </p>
            </div>
            <div class="col-12 col-lg-6 center">
                <div class="row-links mt-2 mb-3">
                    <ul class="row-links-soc">
                        
                        
                        
                        
                    <li class="row-links-soc-item mbr-fonts-style display-7">
                            <a href="#" class="text-danger">contact@NFTUnivers.com</a>
                        </li><li class="row-links-soc-item mbr-fonts-style display-7">
                            <a href="#" class="text-danger">call US :  +33 645 234</a>
                        </li></ul>
                </div>
            </div>
        </div>
    </div>
 
  </body>
</html>