<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the file label or subject ID is set
    if (isset($_POST["fileLabel"]) && isset($_POST["currentState"])) {
        // Get the file label and current state from the form data
        $fileLabel = $_POST["fileLabel"];
        $currentState = $_POST["currentState"];

        // Determine the new state based on the current state
        $newState = $currentState === 'P' ? 'C' : 'P';

        // Update the file state in the database

        include('connection.php');
        // Connexion à la base de données MariaDB
        $stmt = $mysqli->prepare("UPDATE t_fiche_fich SET fic_etat = ? WHERE fic_label = ?");
        $stmt->bind_param("ss", $newState, $fileLabel);
        $stmt->execute();
        $stmt->close();

        $mysqli->close();

        // Redirect back to the previous page after the update
        header("Location: ".$_SERVER['HTTP_REFERER']);
        exit();
    } elseif (isset($_POST["subjectId"])) {
        // Get the subject ID from the form data
        $subjectId = $_POST["subjectId"];

        // Delete the subject and its related files from the database

        // Delete subject
        include('connection.php');
// Connexion à la base de données MariaDB
        $stmt = $mysqli->prepare("DELETE FROM t_sujet_sjt WHERE sjt_id = ?");
        $stmt->bind_param("i", $subjectId);
        $stmt->execute();
        $stmt->close();

        // Delete related files
        $stmt = $mysqli->prepare("DELETE FROM t_fiche_fich WHERE sjt_id = ?");
        $stmt->bind_param("i", $subjectId);
        $stmt->execute();
        $stmt->close();

        $mysqli->close();

        // Redirect back to the previous page after the deletion
        header("Location: ".$_SERVER['HTTP_REFERER']);
        exit();
    } else {
        // Handle missing form data
        echo "Error: Missing form data";
    }
} else {
    // Handle invalid request method
    echo "Error: Invalid request method";
}
?>
