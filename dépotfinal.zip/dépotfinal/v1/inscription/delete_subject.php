<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the subject ID is set
    if (isset($_POST["subjectId"])) {
        // Get the subject ID from the form data
        $subjectId = $_POST["subjectId"];
        // Delete the subject and its related files from the database
                               // Connexion à la base MariaDB         
                               include("connection.php");
        // Delete subject
        $stmt = $mysqli->prepare("DELETE FROM t_sujet_sjt WHERE sjt_id = ?");
        $stmt->bind_param("i", $subjectId);
        $stmt->execute();
        $stmt->close();

        // Delete related files
        $stmt = $mysqli->prepare("DELETE FROM t_fiche_fch WHERE sjt_id = ?");
        $stmt->bind_param("i", $subjectId);
        $stmt->execute();
        $stmt->close();

        $mysqli->close();

        // Redirect back to the previous page after the deletion
        header("Location: ".$_SERVER['HTTP_REFERER']);
        exit();
    } else {
        // Handle missing form data
        echo "Error: Missing form data";
    }
} else {
    // Handle invalid request method
    echo "Error: Invalid request method";
}
?>
