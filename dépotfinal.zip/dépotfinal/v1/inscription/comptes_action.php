<?php
        session_start();
        include('connection.php');
        // Connexion à la base de données MariaDB

        // Handling toggle_statut button
        if (isset($_POST['toggle_statut']) && isset($_POST['pseudosel'])) {
            $pseudo = $_POST['pseudosel'];
            
            // Retrieve user information from the database
            $sql = "SELECT * FROM t_profil_pfl WHERE cpt_pseudo='" . $pseudo . "'";
            $result = $mysqli->query($sql);
            $row = $result->fetch_assoc();

            // Toggle pfl_statut
            if ($row['pfl_statut'] == 'M') {
                $new_statut = 'G';
            } elseif ($row['pfl_statut'] == 'G') {
                $new_statut = 'M';
            }

            // Update pfl_statut in the database
            $update_sql = "UPDATE t_profil_pfl SET pfl_statut='" . $new_statut . "' WHERE cpt_pseudo='" . $pseudo . "'";
            $update_result = $mysqli->query($update_sql);
            
            if ($update_result) {
                // Redirect back to admin_accueil.php after updating
                header("Location: admin_accueil.php");
                exit;
            } else {
                echo "Error updating pfl_statut";
            }
        }

        // Vérifier si le paramètre $_GET['cpt_pseudo'] est défini
        if (isset($_GET['cpt_pseudo'])) {
            $pseudo = $_GET['cpt_pseudo'];

            // Sélectionner les informations de l'utilisateur à partir du pseudo
            $sql = "SELECT * FROM t_profil_pfl WHERE cpt_pseudo='" . $pseudo . "';";
            $result = $mysqli->query($sql);
            $row = $result->fetch_assoc();

            // Vérification et modification de pfl_validite
            if ($row !== null && isset($row['pfl_validite'])) {
                if ($row['pfl_validite'] == 'A') {
                    // Si la validité est 'A', la mettre à 'D'
                    $sql = "UPDATE t_profil_pfl SET pfl_validite='D' WHERE cpt_pseudo='" . $pseudo . "';";
                } elseif ($row['pfl_validite'] == 'D') {
                    // Si la validité est 'D', la mettre à 'A'
                    $sql = "UPDATE t_profil_pfl SET pfl_validite='A' WHERE cpt_pseudo='" . $pseudo . "';";
                }

                // Exécuter la requête de mise à jour
                $result = $mysqli->query($sql);
                if ($result) {
                    // Rediriger vers la page admin_accueil.php après la mise à jour
                    header("location: admin_accueil.php");
                    exit(); // Terminer le script après la redirection
                } else {
                    // Afficher un message d'erreur en cas de problème lors de la mise à jour
                    echo "Erreur lors de la modification.";
                }
            } else {
                // Afficher un message si l'utilisateur n'est pas trouvé dans la base de données
                echo "Utilisateur non trouvé.";
            }
        } else {
            // Afficher un message si le paramètre 'cpt_pseudo' n'est pas défini dans l'URL
            echo "Paramètre 'cpt_pseudo' non défini.";
        }

        // Fermeture de la connexion à la base de données
        $mysqli->close();
?>
