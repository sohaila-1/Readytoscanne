<?php
/* Vérification ci-dessous à faire sur toutes les pages dont l'accès est
autorisé à un utilisateur connecté. */
// connection à la base de donner
include("connection.php");
session_start();
    if (! isset( $_SESSION[ 'login' ] ))
    {
        if (! isset( $_SESSION[ 'role' ] )) {
            //Si la session n'est pas ouverte, redirection vers la page du formulaire de connexion
            header( "Location:openning_session.php" );
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <style>
.container {
    margin-top: 20px;
}

.col-md-6 {
    border: 1px solid #ccc;
    padding: 10px;
    margin-bottom: 20px;
}
        </style>
    </head>

    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="admin_accueil.php">Admine Page</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="try.php">Update</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="deconnection.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="admin_accueil.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Interface</div>
                            <a class="nav-link collapsed" href="admin_accueil.php" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Gestionnement des Profiles
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <a class="nav-link collapsed" href="admin_act.php" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-na•••••••••••••••••••••v-link-icon"><i class="fas fa-columns"></i></div>
                                Gestionnement des Actualités
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <a class="nav-link" href="admin_sujets.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Gestionnement de Sujets et Fiches
                            </a>
                            <a class="nav-link" href="deconnection.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Déconnection
                            </a>
                        </div>
                    </div>
                
                </nav>
            </div>
            <!-- finish side bar -->

            <div id="layoutSidenav_content">
                <main>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Tables</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="admin_accueil.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Table de sujet</li>
                        </ol>
                        <div class="card mb-4">
                             
                        </div>
                        <div class="card mb-4">
                            <div class="card-header">
                                <div class="table-responsive">                                   
                                                
                                <div class="container">
                                <div class="card-body">

                        <?php
                        //connection à la base maria DB 
                        include('connection.php');
                        if ($_SESSION['role'] == 'G') {
                            echo '<div class="text-secondary mb-3"> Supprimer les sujets : </div>';
                            echo '<hr>';
                            // Fetch data from t_sujet_sjt table along with associated file names and creator 
                            $requete_sujet = "SELECT sjt.sjt_id, sjt.sjt_intitule, sjt.cpt_pseudo AS createur, GROUP_CONCAT(fch.fch_label SEPARATOR ', ') AS fiches_associees
                                                FROM t_sujet_sjt sjt
                                                LEFT JOIN t_fiche_fch fch ON sjt.sjt_id = fch.sjt_id
                                                GROUP BY sjt.sjt_id";
                        // requete pour extraire tous les sujets avec leur fiches associer 
                            $resultat_sujet = $mysqli->query($requete_sujet);
                            if ($resultat_sujet === false) {
                                // Error handling
                                echo "Error: La requête a échoué \n";
                                echo "Errno: " . $mysqli->errno . "\n";
                                echo "Error: " . $mysqli->error . "\n";
                                exit();
                            }

                            // Check if the form for deleting a subject has been submitted
                            if (isset($_POST['supprimer']) && isset($_POST['sujet_id'])) {
                                $sujet_id = $_POST['sujet_id'];

                                // Delete the subject from the database
                                $requete_supprimer_sujet = "DELETE FROM t_sujet_sjt WHERE sjt_id = $sujet_id";
                                $resultat_supprimer_sujet = $mysqli->query($requete_supprimer_sujet);

                                if ($resultat_supprimer_sujet === false) {
                                    // Error handling
                                    echo "Error: La suppression du sujet a échoué \n";
                                    echo "Errno: " . $mysqli->errno . "\n";
                                    echo "Error: " . $mysqli->error . "\n";
                                } else {
                                    // Success message
                                    echo '<script>alert("Le sujet a été supprimé avec succès.")</script>';
                                }
                            }

                            // Display the table
                            echo '<table class="table table-striped">';
                            echo '<tr><th>Sujet</th><th>Créateur</th><th>Fiches Associées</th><th>Actions</th></tr>';

                            while ($sujet = $resultat_sujet->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>' . $sujet['sjt_intitule'] . '</td>';
                                echo '<td>' . $sujet['createur'] . '</td>';
                                echo '<td>';
                                // Display files as an unordered list if any
                                if (!empty($sujet['fiches_associees'])) {
                                    echo '<ul>';
                                    $fiches = explode(", ", $sujet['fiches_associees']);
                                    foreach ($fiches as $fiche) {
                                        echo '<li>' . $fiche . '</li>';
                                    }
                                    echo '</ul>';
                                } else {
                                    echo 'Aucune fiche associée';
                                }
                                echo '</td>';
                                echo '<td><form method="POST">';
                                echo '<input type="hidden" name="sujet_id" value="' . $sujet['sjt_id'] . '">';
                                echo '<button type="submit" class="btn btn-danger" name="supprimer">Supprimer</button>';
                                echo '</form></td>';
                                echo '</tr>';
                            }
                            echo '</table>';
                        } else {
                            echo "<div class='display-4 mb-4'>";
                            echo "<div class='text-primary'>";
                            echo "Vous êtes Membre ! ";
                            echo "</div>";
                            echo "</div>";
                        }
                        // fermer la base de donner
                        $mysqli->close();
                        ?>

                         </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
