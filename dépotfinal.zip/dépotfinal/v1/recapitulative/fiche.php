
<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v5.9.17, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v5.9.17, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="asset/images/logo5.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Page 5</title>

  <link rel="stylesheet" href="asset/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="asset/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="asset/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="asset/animatecss/animate.css">
  <link rel="stylesheet" href="asset/theme/css/style.css">
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Inter+Tight:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
  <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter+Tight:100,200,300,400,500,600,700,800,900,100i,200i,300i,400i,500i,600i,700i,800i,900i&display=swap"></noscript>
  <link rel="preload" as="style" href="asset/mobirise/css/mbr-additional.css?v=S60xhT"><link rel="stylesheet" href="asset/mobirise/css/mbr-additional.css?v=S60xhT" type="text/css">
<style>
  .styled-frame {
    border: 2px solid black;
    padding: 10px;
    margin-bottom: 20px;
}

.link {
    text-decoration: none;
    color: red;
}

.link:hover {
    color: #000;
}
  
</style>
</head>
<body>
  <section data-bs-version="5.1" class="menu menu5 cid-u76g7t6F8u" once="menu" id="menu05-21">
	

    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
      <div class="container">
        <div class="navbar-brand">
          
          <span class="navbar-caption-wrap"><a class="navbar-caption text-black display-4" href="../index.php">NFTUniverse</a></span>
        </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <div class="hamburger">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
          </div>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
              <a class="nav-link link text-black display-4" href="../index.php">News</a>
            </li>
            <li class="nav-item">
              <a class="nav-link link text-black display-4" href="../recapitulative/repertoir.php" aria-expanded="false">content</a>
            </li>
            <li class="nav-item">
              <a class="nav-link link text-black display-4" href="../index.php#footer02-2q">Contacts</a>
            </li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-info display-4" href="inscription/inscription.php"> Sign Up</a></div>
        <span style="margin: 0 10px;"></span>
        <div class="navbar-buttons mbr-section-btn"><a class="btn btn-info display-4" href="inscription/opening_session.php"> Sign In</a></div>
        </div>
      </div>
    </nav>
  </section>
  <section data-bs-version="5.1" class="image01 cid-u8pY74KyRE" id="image01-2n">
  <!-- starting section php to show the details for every card -->

<?php
        //connection to data base 
        include("connection.php");
      // Vérifiez si le code de la fiche est présent dans l'URL
      if (isset($_GET['fch_code'])) {
          // Récupérez le code de la fiche de l'URL
          $fic_code = $_GET['fch_code'];  
          // Vérifiez si le code de la fiche a une longueur de 12 caractères
          if (strlen($fic_code) === 12) {
              // Utilisez le code de la fiche en toute sécurité
              // requete pour extraire chaque fiche avec ses données à travers son code
              $sql = "SELECT f.*, s.sjt_intitule 
              FROM t_fiche_fch f 
              JOIN t_sujet_sjt s ON f.sjt_id = s.sjt_id 
              WHERE f.fch_code = '$fic_code';";  
              $result = $mysqli->query($sql);
              if ($result->num_rows > 0) {
                  $row = $result->fetch_assoc();       
?>
      <!-- affichage de chaque fiche -->

      <div class="container">
          <div class="row justify-content-center">
              <div class="col-12 col-lg-6">
                  <div class="image-wrapper mb-4">
                      <!-- affichage de l'image de fiche et l'intitule de son sujet , aussi le contenue de fiche et ses hyperlien -->
                      <img class="w-60 h-50" src="images/<?php echo $row['fch_image']; ?>" alt="">
                  </div>
                  <!-- affichage de l'intitule de sujet , aussi le contenue de fiche et ses hyperlien -->
                  <h4 class="mbr-description mbr-fonts-style mb-3 align-center display-5">
                      <strong><?php echo $row['sjt_intitule']; ?></strong>
                  </h4>
                  <h4 class="mbr-description mbr-fonts-style mb-0 align-center display-7">
                      <?php echo $row['fch_contenu']; 
                      $requete_sujets = "select * from t_sujet_sjt;";
                      $resultat_sujet = $mysqli->query($requete_sujets); 
                      $sujet = $resultat_sujet->fetch_assoc();
                       
                      
                      ?>
                      <br><br>
                      <h5 class="mbr-description mbr-fonts-style mb-3 align-center display-5">The creator:</h5>
                      <h5 class="mbr-description mbr-fonts-style mb-3 align-center display-5">
                          <strong><?php echo $sujet['cpt_pseudo']; ?></strong>
                      </h5>
                  </div>
                  <div class="styled-frame">
                      <?php  
                      //prepare et execute la requete qui collecte les hyperliens associers avec les fiches 
                      $requete_hyperliens = "SELECT * FROM t_hyperlien_hpl WHERE hpl_id IN 
                      (SELECT hpl_id FROM t_liaison_lsn WHERE fch_id = 
                      (SELECT fch_id FROM t_fiche_fch WHERE fch_code = '$fic_code'));";
      $result_hyperliens = $mysqli->query($requete_hyperliens);


      if ($result_hyperliens && $result_hyperliens->num_rows > 0) {
        // Output the hyperlinks associated with a fiche
        echo '<div class="card-body bg-light p-4">';
        echo '<div class="text-secondary mb-3">Informations complémentaires - hyperliens vers d\'autres pages web: </div>';
        while ($hyperlien = $result_hyperliens->fetch_assoc()) {
            echo '<p class="text-center"><a href="' . $hyperlien['hpl_url'] . '" " target="_blank">' . $hyperlien['hpl_nom'] . '</a></p>';
        }
        echo '</div>'; 
      } elseif ($result_hyperliens && $result_hyperliens->num_rows === 0) {
        // Display a message if there are no hyperlinks associated with the fiche
        echo '<p style="text-align: center; color: red;">No hyperlinks available for this fiche.</p>';
      } else {
        // Display an error message if there is an error retrieving hyperlinks
        echo "Error retrieving hyperlinks: " . $mysqli->error;
      }
?>
            </div>
        </div>
    </div>
</div>
<?php    
        } else {
?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-lg-6">
            <p style="color: red; text-align: center;"><strong>We are sorry, this card is not available at the moment. We will keep you updated when it's online.</strong></p>
        </div>
    </div>
</div>
<?php
        }
    } else {
        echo "Invalid fic_code length";
    }
} else {
    echo "fic_code parameter is missing";
}
//fermer l'accés à la base de donner
$mysqli->close();
?>

</section><section class="display-7" style="padding: 0;align-items: center;justify-content: center;flex-wrap: wrap;    align-content: center;display: flex;position: relative;height: 4rem;"><a href="https://mobiri.se/2318866" style="flex: 1 1;height: 4rem;position: absolute;width: 100%;z-index: 1;"><img alt="" style="height: 4rem;" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="></a>
</section><script src="asset/bootstrap/js/bootstrap.bundle.min.js"></script>  <script src="asset/smoothscroll/smooth-scroll.js"></script>  <script src="asset/ytplayer/index.js"></script> 
 <script src="asset/theme/js/script.js"></script>  

  </body>
</html>